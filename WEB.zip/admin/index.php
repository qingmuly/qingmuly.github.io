﻿<?PHP include("../php/V1.php");  ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>吾爱免流云流量平台</title>
<link href="../css/zui.css" rel="stylesheet" type="text/css" />
<link href="../css/zui.lite.css" rel="stylesheet" type="text/css" />
<link href="../css/zui.lite.min.css" rel="stylesheet" type="text/css" />
<link href="../css/zui.min.css" rel="stylesheet" type="text/css" />
<link href="../css/zui-theme.css" rel="stylesheet" type="text/css" />
<link href="../css/zui-theme.min.css" rel="stylesheet" type="text/css" />
<link href="../css/css.css" rel="stylesheet" type="text/css" />
<link rel="icon" type="image/x-icon" href="img/favicon.ico">
<script src="../js/zui.min.js"></script>
<script src="../js/doc.min.js"></script>
<script src="../js/jquery.js"></script>
<script src="../js/admin.js"></script>
<style type="text/css">
<!--
.STYLE1 {color: #000;font-family: "Microsoft YaHei","微软雅黑","Trebuchet MS",Arial,Verdana,Tahoma,sans-serif;}
.STYLE2 {color: #FFF}
-->
</style>
</head>

<body>

 <div class="bg-image-pattern"></div>
<div align="center">  
<img class="bg-image" src="/img/bj.jpg">
 
 <div class="wrapper">
 <img src='/img/wifi.png'width='50%'height='50'/>
 <h1 class="STYLE1"> 后台管理</h1>
<br/>	


<div id="x">
		 
		 <button onclick="a()" class="btn btn-block btn-primary" type="button">增加流量</button>
		 <br/>
		 <button onclick="b()" class="btn btn-block btn-info" type="button">停用帐号</button>
		  <br/>
		 <button onclick="c();" class="btn  btn-block btn-success" type="button">删除帐号</button>
		  <br/>
		 <button onclick="d();" class="btn btn-block btn-warning" type="button">修改管理密码</button>
		 <br/>
		 <button onclick="e();" class="btn btn-block btn-danger" type="button">会员列表</button>
		 <br/>
		  <button onclick="f()" class="btn btn-block btn-primary" type="button">生成帐号</button>
        <br/>
		 <button onclick="g()" class="btn btn-block btn-info" type="button">找回密码</button>
</div>


 





 </div>
</div align="center">




 <div>
   <div align="center" class="STYLE2">官方QQ群：<a href="http://shang.qq.com/wpa/qunwpa?idkey=9c5042ab2554a88dd18e4a0c74dceefb2a6cedc4fdc9d0eb0a08722931db5f01" title="339323137" target="_blank">339323137</a> <br/>
   Copyright © 2015 - 2016. All Rights Reserved <br/> 
   <a href="http://www.52ml.org" title="吾爱免流" target="_blank">吾爱免流</a> 版权所有 </div>
 </div>

</body>
</html>






 


