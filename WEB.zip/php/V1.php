<?php
session_start();
?>
<?php
include("conn.php");



$_COOKIE['D'] = $D;
$_COOKIE['E'] = $E;

function ZC($U, $P, $Y)
{

	$U = trim($U);
	$P = trim($P);
	$Y = trim($Y);

	IF ($U == "" || $P == "" || $Y == "") {

		return "4";  //����������

	}


	$SQL = "SELECT * 
FROM  `openvpn` 
WHERE  `iuser` LIKE  '" . $U . "'
LIMIT 0 , 30";
	$FH = mysql_query($SQL);
	$SJ = mysql_fetch_array($FH);

	IF ($SJ["iuser"] == "") {


		$rq = date("Y-m-d", time());
		$rqa = date("Y-m-d", time() + 60 * 60 * 24 * 30);
		$SQL = "INSERT INTO  `" . $_COOKIE['D'] . "`.`openvpn` (
`id` ,
`iuser` ,
`isent` ,
`irecv` ,
`maxll` ,
`pass` ,
`i` ,
`starttime` ,
`rq` ,
`YX`
)
VALUES (
NULL ,  '" . $U . "',  '0',  '0',  '0',  '" . $P . "',  '1',  '" . $rq . "',  '" . $rqa . "',  '" . $Y . "'
);";

		IF (mysql_query($SQL)) {


			return "3";    //ע��ɹ�

		}
		return "2";//ע��ʧ��


	}
	return "1";//�ʺ���ע��

}


function C($U, $P)
{

	$U = trim($U);
	$P = trim($P);
	IF ($U == "" || $P == "") {

		return "1";  //����������

	}

	$SQL = "SELECT * 
FROM  `openvpn` 
WHERE  `iuser` LIKE  '$U'
AND  `pass` LIKE  '$P'
LIMIT 0 , 30";
	$FH = mysql_query($SQL);
	$SJ = mysql_fetch_array($FH);

	IF ($SJ['iuser'] == $U && $SJ['pass'] == $P) {


		$url = $_COOKIE['E'] . "log.php";
		$contents = file_get_contents($url);
		$getcontent = iconv("gb2312", "utf-8", file_get_contents($url));
		IF (strpos($getcontent, $_POST['u']) != false) {
			$XZ = "������";
		}
		IF (strpos($getcontent, $_POST['u']) == false) {
			$XZ = "δ����";
		}


		$SJ['isent'] = $SJ['isent'] / 1024 / 1024;
		$SJ['irecv'] = $SJ['irecv'] / 1024 / 1024;
		$SJ['maxll'] = $SJ['maxll'] / 1024 / 1024;


		$SJ['isent'] = floor($SJ['isent']);
		$SJ['irecv'] = floor($SJ['irecv']);
		$SJ['maxll'] = floor($SJ['maxll']);


		$SSS = strtotime($SJ['rq']);
		$SSSA = strtotime($SJ['starttime']);
		$RQQ = $SSS - time();
		$RQQ = $RQQ / 60 / 60 / 24;
		$RQQ = floor($RQQ);
		$aaa = $SJ['maxll'] - $SJ['irecv'] - $SJ['isent'];
		if ($SJ['i'] == "1") {
			$SJ['T'] = "����";

		}
		if ($SJ['i'] == "0") {
			$SJ['T'] = "ͣ��";

		}
		$BC = "
 
 
 <table  class=\"table table-bordered\">
  <tr>
    <td>��Ա�ʺţ�</td>
    <td>" . $SJ['iuser'] . "</td>
  </tr>
  <tr>
    <td>��Ա״̬��</td>
    <td>" . $SJ['T'] . "</td>
  </tr>
  <tr>
    <td>�Ѿ��ϴ���</td>
    <td>" . $SJ['isent'] . "M</td>
  </tr>
  <tr>
    <td>�Ѿ����أ�</td>
    <td>" . $SJ['irecv'] . "M</td>
  </tr>
  <tr>
    <td>�ܹ�������</td>
    <td>" . $SJ['maxll'] . "M</td>
  </tr>
  <tr>
    <td>ʣ��������</td>
    <td>" . $aaa . "M</td>
  </tr>
  <tr>
    <td>��ͨʱ�䣺</td>
    <td>" . $SJ['starttime'] . "</td>
  </tr>
  <tr>
   <tr>
    <td>����ʱ�䣺</td>
    <td>" . $SJ['rq'] . "</td>
  </tr>
  <tr>
    <td>ʣ��ʱ�䣺</td>
    <td>" . $RQQ . "��</td>
  </tr>
  <tr>
    <td>�Ƿ����ߣ�</td>
    <td>" . $XZ . "</td>
  </tr>
 </table>
<a href=\"http://www.52ml.org/OpenVPN.apk\" class=\"btn  btn-block btn-success\">���ؿͻ���</a></br>
 
 

 ";

		$BC = iconv("GB2312", "UTF-8", $BC);

		return $BC;


	}
	return "2";  //�ʺ��������


}


function admin($U, $P)
{

	$U = trim($U);
	$P = trim($P);
	IF ($U == "" || $P == "") {

		return "1";  //����������

	}


	$SQL = "SELECT * 
FROM  `admin` 
WHERE  `u` LIKE  '$U'
AND  `p` LIKE  '$P'
LIMIT 0 , 30";

	$FH = mysql_query($SQL);
	$SJ = mysql_fetch_array($FH);

	IF ($SJ['u'] == $U && $SJ['u'] == $P) {

		$_SESSION['admin'] = "ok";
		return "3";  //��¼�ɹ�


	}
	return "2";  //�ʺ��������


}


function admin_l($amdin, $U, $L)
{


	$SQL = "SELECT * 
FROM  `admin` 
LIMIT 0 , 30";
	$FH = mysql_query($SQL);
	$SJ = mysql_fetch_array($FH);
	IF ($SJ['p'] == $amdin) {

		$L = $L * 1024 * 1024;

		$SQL = "SELECT * 
FROM  `openvpn` 
WHERE  `iuser` LIKE  '" . $U . "'
LIMIT 0 , 30";
		$FH = mysql_query($SQL);
		$SJ = mysql_fetch_array($FH);
		IF ($SJ['iuser'] != "") {

			$LL = $SJ['maxll'] + $L;
			$SQL = "UPDATE  `" . $_COOKIE['D'] . "`.`openvpn` SET  `maxll` =  '" . $LL . "' WHERE  `openvpn`.`id` =" . $SJ['id'] . " LIMIT 1 ;";
			if (mysql_query($SQL)) {

				return "3";//���ӳɹ�

			}
			return "2";//����ʧ��


		}
		return "1";//�ʺŲ�����


	}
	return "4";//�����������


}


function admin_z($amdin, $U, $Z)
{

	$SQL = "SELECT * 
FROM  `admin` 
LIMIT 0 , 30";
	$FH = mysql_query($SQL);
	$SJ = mysql_fetch_array($FH);
	IF ($SJ['p'] == $amdin) {

		$SQL = "SELECT * 
FROM  `openvpn` 
WHERE  `iuser` LIKE  '" . $U . "'
LIMIT 0 , 30";
		$FH = mysql_query($SQL);
		$SJ = mysql_fetch_array($FH);
		IF ($SJ['iuser'] != "") {

			IF ($Z == "1") {

				$SQL = "UPDATE  `" . $_COOKIE['D'] . "`.`openvpn` SET  `i` =  '1' WHERE  `openvpn`.`id` =" . $SJ['id'] . " LIMIT 1 ;";
				if (mysql_query($SQL)) {

					return "3";//�޸ĳɹ�


				}
				return "1";//�޸�ʧ��

			}
			IF ($Z == "2") {

				$SQL = "UPDATE  `" . $_COOKIE['D'] . "`.`openvpn` SET  `i` =  '0' WHERE  `openvpn`.`id` =" . $SJ['id'] . " LIMIT 1 ;";
				if (mysql_query($SQL)) {

					return "3";//�޸ĳɹ�


				}
				return "1";//�޸�ʧ��

			}
			IF ($Z == "4") {

				$SQL = "DELETE FROM `openvpn` WHERE `openvpn`.`id` = " . $SJ['id'] . " LIMIT 1";
				if (mysql_query($SQL)) {

					return "3";//�޸ĳɹ�


				}
				return "1";//�޸�ʧ��

			}
			IF ($Z == "3") {

				$rq = date("Y-m-d", time());
				$rqa = date("Y-m-d", time() + 60 * 60 * 24 * 30);

				$SQL = "UPDATE  `" . $_COOKIE['D'] . "`.`openvpn` SET  
`isent` =  '0',
`irecv` =  '0',
`maxll` =  '0',
`i` =  '1',
`starttime` =  '" . $rq . "',
`rq` =  '" . $rqa . "' 
WHERE  `openvpn`.`id` =" . $SJ['id'] . " LIMIT 1";


				if (mysql_query($SQL)) {

					return "3";//�޸ĳɹ�


				}
				return "1";//�޸�ʧ��

			}


		}
		return "4";//�ʺŲ�����


	}
	return "5";//�����������


}


function admin_g($_admin, $admin_a)
{

	$SQL = "SELECT * 
FROM  `admin` 
WHERE  `p` LIKE  '" . $_admin . "'
LIMIT 0 , 30";

	$FH = mysql_query($SQL);
	$SJ = mysql_fetch_array($FH);
	if ($SJ["p"] == $_admin) {

		$SQL = "UPDATE  `" . $_COOKIE['D'] . "`.`admin` SET  `p` =  '" . $admin_a . "' WHERE  `admin`.`id` =1 LIMIT 1 ;";

		IF (mysql_query($SQL)) {

			return "3";//�޸ĳɹ�

		}
		return "2";//�޸�ʧ��


	}
	return "1";//�����ʺŴ���


}


function admin_s($ADMIN, $L, $lL)
{
	$lL = $lL * 1024 * 1024;

	$SQL = "SELECT * 
FROM  `admin` 
WHERE  `p` LIKE  '" . $ADMIN . "'
LIMIT 0 , 30";

	$FH = mysql_query($SQL);
	$SJ = mysql_fetch_array($FH);
	if ($SJ["p"] == $ADMIN) {

		$x = 1;
		while ($x <= $L) {
			$U = rand(1000000, 9999999);
			$P = rand(1000000, 9999999);

			$rq = date("Y-m-d", time());
			$rqa = date("Y-m-d", time() + 60 * 60 * 24 * 30);
			$SQL = "INSERT INTO  `" . $_COOKIE['D'] . "`.`openvpn` (
`id` ,
`iuser` ,
`isent` ,
`irecv` ,
`maxll` ,
`pass` ,
`i` ,
`starttime` ,
`rq` ,
`YX`
)
VALUES (
NULL ,  '" . $U . "',  '0',  '0',  '" . $lL . "',  '" . $P . "',  '1',  '" . $rq . "',  '" . $rqa . "',  '" . $Y . "'
);";

			IF (mysql_query($SQL)) {


				$AA = iconv("GBK", "UTF-8", "��Ա�ʺţ�$U ��Ա���룺$P <br/>");

				echo($AA);    //ע��ɹ�
				//EXIT();
				$x++;
			}
			return "2";//ע��ʧ��


		}


	}
	return "1";//�����ʺŴ���


}


function admin_k($ADMIN, $L)
{


	$SQL = "SELECT * 
FROM  `admin` 
WHERE  `p` LIKE  '" . $ADMIN . "'
LIMIT 0 , 30";

	$FH = mysql_query($SQL);
	$SJ = mysql_fetch_array($FH);
	if ($SJ["p"] == $ADMIN) {


		$SQL = "SELECT * 
FROM  `openvpn` 
WHERE  `iuser` LIKE  '" . $L . "'
LIMIT 0 , 30";
		$FH = mysql_query($SQL);
		$SJ = mysql_fetch_array($FH);
		if ($SJ['iuser'] == $L) {

			return "pass|" . $SJ['pass'];//�ʺŲ�����

		}
		return "2";//�ʺŲ�����


	}
	return "1";//�����ʺŴ���


}


function admin_dl($admin, $U, $Q)
{

	$SQL = "SELECT * 
FROM  `admin` 
WHERE  `p` LIKE  '" . $admin . "'
LIMIT 0 , 30";

	$FH = mysql_query($SQL);
	$SJ = mysql_fetch_array($FH);
	if ($SJ["p"] == $admin) {


		$SQL = "SELECT * 
FROM  `openvpn` 
WHERE  `iuser` LIKE  '" . $U . "'
LIMIT 0 , 30";
		$FH = mysql_query($SQL);
		$SJ = mysql_fetch_array($FH);
		$ID = $SJ['id'];
		if ($SJ['iuser'] == $U) {


			$SQL = "UPDATE  `" . $_COOKIE['D'] . "`.`openvpn` SET  `rq` =  '2019-12-30',`a` =  '" . $Q . "' WHERE  `openvpn`.`id` =" . $ID . " LIMIT 1 ;";
			IF (mysql_query($SQL)) {


				return "3";//�޸ĳɹ�

			}
			return "4";//�޸�ʧ��


		}
		return "2";//�ʺŲ�����


	}
	return "1";//�����ʺŴ���

}


function dl_C($U, $P)
{

	$U = trim($U);
	$P = trim($P);
	IF ($U == "" || $P == "") {

		return "1";  //����������

	}

	$SQL = "SELECT * 
FROM  `openvpn` 
WHERE  `iuser` LIKE  '$U'
AND  `pass` LIKE  '$P'
LIMIT 0 , 30";
	$FH = mysql_query($SQL);
	$SJ = mysql_fetch_array($FH);

	IF ($SJ['iuser'] == $U && $SJ['pass'] == $P) {


		$url = $_COOKIE['E'] . "log.php";
		$contents = file_get_contents($url);
		$getcontent = iconv("gb2312", "utf-8", file_get_contents($url));
		IF (strpos($getcontent, $_POST['u']) != false) {
			$XZ = "������";
		}
		IF (strpos($getcontent, $_POST['u']) == false) {
			$XZ = "δ����";
		}


		$SJ['isent'] = $SJ['isent'] / 1024 / 1024;
		$SJ['irecv'] = $SJ['irecv'] / 1024 / 1024;
		$SJ['maxll'] = $SJ['maxll'] / 1024 / 1024;


		$SJ['isent'] = floor($SJ['isent']);
		$SJ['irecv'] = floor($SJ['irecv']);
		$SJ['maxll'] = floor($SJ['maxll']);


		$SSS = strtotime($SJ['rq']);
		$SSSA = strtotime($SJ['starttime']);
		$RQQ = $SSS - time();
		$RQQ = $RQQ / 60 / 60 / 24;
		$RQQ = floor($RQQ);
		$aaa = $SJ['maxll'] - $SJ['irecv'] - $SJ['isent'];
		if ($SJ['i'] == "1") {
			$SJ['T'] = "����";

		}
		if ($SJ['i'] == "2") {
			$SJ['T'] = "ͣ��";

		}
		if ($SJ['a'] == "0") {

			return "3";  //���ʺ�δ��ͨ����

		}
		if ($SJ['a'] == "") {

			return "3";  //���ʺ�δ��ͨ����

		}
		if ($SJ['a'] == "1") {


			$BC = "
 
 
 <table  class=\"table table-bordered\">
  <tr>
    <td>��Ա�ʺţ�</td>
    <td>" . $SJ['iuser'] . "</td>
  </tr>
  <tr>
    <td>��Ա״̬��</td>
    <td>" . $SJ['T'] . "</td>
  </tr>
  
  <tr>
    <td>�ܹ�������</td>
    <td>" . $SJ['maxll'] . "M</td>
  </tr>
  <tr>
    <td>ʣ��������</td>
    <td>" . $aaa . "M</td>
  </tr>
  <tr>
    <td>�Ƿ����ߣ�</td>
    <td>" . $XZ . "</td>
  </tr>
</table>
<br/>
 
 

 ";

			$BC = iconv("GB2312", "UTF-8", $BC);

			return $BC;


		}
		return "3";  //���ʺ�δ��ͨ����


	}
	return "2";  //�ʺ��������


}


function dl_l($U, $P, $AU, $L)
{

	if ($L < 1) {
		return "7";  //��ֹ����

	}


	$SQL = "SELECT * 
FROM  `openvpn` 
WHERE  `iuser` LIKE  '$U'
AND  `pass` LIKE  '$P'
LIMIT 0 , 30";
	$FH = mysql_query($SQL);
	$SJ = mysql_fetch_array($FH);
	IF ($SJ['iuser'] == $U && $SJ['pass'] == $P) {


		$s = $SJ['maxll'] - ($SJ['irecv'] + $SJ['isent']);
		$L = $L * 1024 * 1024;
		$DLID = $SJ['id'];
		if ($SJ['a'] == "1") {

			$LLL = $s - $L;
			if ($LLL > 1) {


				$SQL = "SELECT * 
FROM  `openvpn` 
WHERE  `iuser` LIKE  '$AU'
LIMIT 0 , 30";
				$FH = mysql_query($SQL);
				$SJ = mysql_fetch_array($FH);
				$ID = $SJ['id'];
				$LLA = $SJ['maxll'];
				$LLA = $LLA + $L * 1024;
				$SQL = "UPDATE  `" . $_COOKIE['D'] . "`.`openvpn` SET  `maxll` =  '$LLA' WHERE  `openvpn`.`id` =$ID LIMIT 1 ;";
				IF (mysql_query($SQL)) {


					$SQL = "UPDATE  `" . $_COOKIE['D'] . "`.`openvpn` SET  `maxll` =  '$LLL' WHERE  `openvpn`.`id` =$DLID LIMIT 1 ;";
					IF (mysql_query($SQL)) {

						return "6";  //ת�����ɹ�

					}
					return "5";  //ת����ʧ��


				}
				return "4";  //��Ա��������ʧ��


			}
			return "3";  //��������


		}
		return "2";  //�޴���


	}
	return "1";  //�ʺ��������


}


function admin_ts($amdin, $U, $L)
{


	$SQL = "SELECT * 
FROM  `admin` 
LIMIT 0 , 30";
	$FH = mysql_query($SQL);
	$SJ = mysql_fetch_array($FH);
	IF ($SJ['p'] == $amdin) {


		$SQL = "SELECT * 
FROM  `openvpn` 
WHERE  `iuser` LIKE  '" . $U . "'
LIMIT 0 , 30";
		$FH = mysql_query($SQL);
		$SJ = mysql_fetch_array($FH);
		$TS = strtotime($SJ["rq"]);
		$TS = $TS + $L * 60 * 60 * 24;
		$TS = date('Y-m-d', $TS);


		IF ($SJ['iuser'] != "") {

			$LL = $SJ['maxll'] + $L;
			$SQL = "UPDATE  `" . $_COOKIE['D'] . "`.`openvpn` SET  `rq` =  '" . $TS . "' WHERE  `openvpn`.`id` =" . $SJ['id'] . " LIMIT 1 ;";
			if (mysql_query($SQL)) {

				return "3";//���ӳɹ�

			}
			return "2";//����ʧ��


		}
		return "1";//�ʺŲ�����


	}
	return "4";//�����������


}