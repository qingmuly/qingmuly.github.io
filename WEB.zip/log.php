
<body style="color:rgb(0, 255, 245);font-size:18px;background-image:url(./img/abcd.jpg);background-position: center center;background-repeat: no-repeat;background-attachment: fixed;background-size: cover;">
<div style="margin:5% auto;width:650px;">
<?php
header("Content-type: text/html; charset=GBK"); 
$name;
$ip;
$sent=0;
$recv=0;
$str=file_get_contents("./res/openvpn-status.txt");
$num=(substr_count($str,'2016')-1)/2;
//echo $num;
$fp=fopen("./res/openvpn-status.txt","r");
fgets($fp);
fgets($fp);
fgets($fp);
for($i=0;$i!=$num;$i++){
$line=fgets($fp);
$arr=explode(",",$line);
$recv=ceil($arr[2]/1024)/1000;
$sent=ceil($arr[3]/1024)/1000;
echo "�û���:".$arr[0]."-";
echo "IP:".$arr[1]."-";
echo "�ϴ�:".$recv."MB-";
echo "����:".$sent."MB<br /><br /><br /><br />";
}
?>
</div>
</body>