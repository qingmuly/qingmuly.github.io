var xmlhttp;
if (window.XMLHttpRequest)
  {// code for IE7+, Firefox, Chrome, Opera, Safari
  xmlhttp=new XMLHttpRequest();
  }
else
  {// code for IE6, IE5
  xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  
  
  function zc(){
    
var u=document.getElementById("u").value;
var p=document.getElementById("p").value;
var y=document.getElementById("y").value;

if(u==""){
	
	alert("请输入会员帐号");
	exit();
	
	}if(p==""){
	
	alert("请输入会员密码");
	exit();
	
	}if(y==""){
	
	alert("请输入会员邮箱");
	exit();
	
	}
    
xmlhttp.open("POST","php/k.php?b=ok",false);
xmlhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
xmlhttp.send("u="+u+"&p="+p+"&y="+y);
var fh=xmlhttp.responseText; 

 if(fh=="1"){
	
	alert("帐号已经被注册");
	exit();
	
	} if(fh=="2"){
	
	alert("帐号注册失败");
	exit();
	
	}if(fh=="3"){
	
	alert("帐号注册成功");
	
	document.getElementById("x").innerHTML="<table class='table table-bordered'><tr><td>会员帐号：</td><td>"+u+"</td></tr><tr><td>帐号密码：</td><td>"+p+"</td></tr><tr><td>当前流量：</td><td>0.0M</td></tr></table><h3><a href='http://www.52ml.org/OpenVPN.apk'> 客户端下载：OpenVPN.apk</a></h3>";  
	
	
	
	
	exit();
	
	}if(fh=="4"){
	
	alert("参数不完整");
	exit();
	
	}
    
    
    
  }
  
  
  
  
   function bba(){
    
var u=document.getElementById("u").value;
var p=document.getElementById("p").value; 
if(u==""){
	
	alert("请输入会员帐号");
	exit();
	
	}if(p==""){
	
	alert("请输入会员密码");
	exit();
	
	}    
    
xmlhttp.open("POST","php/k.php?a=ok",false);
xmlhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
xmlhttp.send("u="+u+"&p="+p);

if(xmlhttp.responseText==""){
	
	document.getElementById("x").innerHTML="no";   
	exit();
	
	}

document.getElementById("x").innerHTML=xmlhttp.responseText;    
    
    
  }
  
  
   function al(){
	   
	   
	   
var u=document.getElementById("u").value;
var l=document.getElementById("l").value; 
if(u==""){
	
	alert("请输入会员帐号");
	exit();
	
	}if(l==""){
	
	alert("请输入需要增长的流量");
	exit();
	
	} 
    

xmlhttp.open("POST","admin_a.php",false);
xmlhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
xmlhttp.send("u="+u+"&l="+l);
var fh=xmlhttp.responseText; 
if(fh!=""){
	
	
	if(fh=="1"){
		
		alert("帐号不存在");
	    exit();
		}if(fh=="2"){
		
		alert("添加失败");
	    exit();
		}if(fh=="3"){
		
		alert("添加成功");
	    exit();
		}
	
	
	}
alert("未知错误");
exit();	   
	   
	   
	   
	   }
       
       
       
       
       
       
       
   function aal(){
	   
	   
	   
var u=document.getElementById("u").value;
var l=document.getElementById("i").value; 
if(u==""){
	
	alert("请输入会员帐号");
	exit();
	
	}if(l==""){
	
	alert("请输入1-4");
	exit();
	
	}
    

xmlhttp.open("POST","admin_b.php",false);
xmlhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
xmlhttp.send("u="+u+"&l="+l);
var fh=xmlhttp.responseText; 
if(fh!=""){
	
	
	if(fh=="1"){
		
		alert("帐号不存在");
	    exit();
		}if(fh=="2"){
		
		alert("修改失败");
	    exit();
		}if(fh=="3"){
		
		alert("修改成功");
	    exit();
		}
	
	
	}
alert("未知错误");
exit();	   
	   
	   
	   
	   }       
       
       
  function zc_a(){       
document.getElementById("x").innerHTML="<div class='input-group'><span class='input-group-addon'><i class='icon icon-user'></i></span><input type='text'name='u'id='u'value=''class='form-control'placeholder='帐号'><span class='input-group-addon'>会员帐号</span></div><BR/><div class='input-group'><span class='input-group-addon'><i class='icon icon-eye-open'></i></span><input type='text'name='p'id='p'value=''class='form-control'placeholder='密码'><span class='input-group-addon'>会员密码</span></div><br/><div class='input-group'><span class='input-group-addon'><i class='icon icon-envelope-alt'></i></span><input type='text'name='y'id='y'value=''class='form-control'placeholder='邮箱'><span class='input-group-addon'>会员邮箱</span></div><br/>&nbsp;<button onclick='zc()'class='btn btn-success 'type='button'>立即注册</button>&nbsp;<button onclick='bba_a()'class='btn btn-primary'type='button'>会员登录</button>&nbsp;<button onclick='alert(\"请联系客服\");' class='btn btn-primary' type='button'>忘记密码</button></div>";  }


  function bba_a(){       
document.getElementById("x").innerHTML="<div class='input-group'><span class='input-group-addon'><i class='icon icon-user'></i></span><input type='text'name='u'id='u'value=''class='form-control'placeholder='帐号'><span class='input-group-addon'>会员帐号</span></div><BR/><div class='input-group'><span class='input-group-addon'><i class='icon icon-eye-open'></i></span><input type='text'name='p'id='p'value=''class='form-control'placeholder='密码'><span class='input-group-addon'>会员密码</span></div><br/>&nbsp<button onclick='bba()'class='btn btn-success'type='button'>立即登录</button>&nbsp<button onclick='zc_a()'class='btn btn-primary'type='button'>注册会员</button>&nbsp<button onclick='alert(\"请联系客服\");' class='btn btn-primary' type='button'>忘记密码</button></div><div>"; }







