// JavaScript Document


var xmlhttp;
if (window.XMLHttpRequest)
  {// code for IE7+, Firefox, Chrome, Opera, Safari
  xmlhttp=new XMLHttpRequest();
  }
else
  {// code for IE6, IE5
  xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  
 
 
 
  function a(){
	  
	  document.getElementById("x").innerHTML="<div class='input-group'><span class='input-group-addon'><i class='icon icon-eye-open'></i></span><input type='text'name='admin'id='admin'value=''class='form-control'placeholder='管理密码'><span class='input-group-addon'>管理密码</span></div><BR/><div class='input-group'><span class='input-group-addon'><i class='icon icon-user'></i></span><input type='text'name='u'id='u'value=''class='form-control'placeholder='会员帐号'><span class='input-group-addon'>会员帐号</span></div><BR/><div class='input-group'><span class='input-group-addon'><i class='icon icon-cloud'></i></span><input type='text'name='l'id='l'value=''class='form-control'placeholder='添加流量'><span class='input-group-addon'>添加流量</span></div><BR/><button onclick='admin_a();'class='btn btn-block btn-warning'type='button'>确定添加</button><br/><button onclick='fh()'class='btn btn-block btn-primary'type='button'>返回主页</button>";
	  
	  }
	  
	  
	  
  function b(){
	  
	  document.getElementById("x").innerHTML="<div class='input-group'><span class='input-group-addon'><i class='icon icon-eye-open'></i></span><input type='text'name='admin'id='admin'value=''class='form-control'placeholder='管理密码'><span class='input-group-addon'>管理密码</span></div><BR/><div class='input-group'><span class='input-group-addon'><i class='icon icon-user'></i></span><input type='text'name='u'id='u'value=''class='form-control'placeholder='会员帐号'><span class='input-group-addon'>会员帐号</span></div><BR/><div class='input-group'><select class='form-control btn-block'name='t' id='t'><option value='1'>选择-帐号正常</option><option value='2'>选择-帐号停用</option><option value='3'>选择-帐号重置</option></select></div><BR/><button onclick='admin_b();'class='btn btn-block btn-warning'type='button'>确定修改</button><br/><button onclick='fh()'class='btn btn-block btn-primary'type='button'>返回主页</button>";
	  
	  }	 
	  
	  
	  function c(){
	  
	  document.getElementById("x").innerHTML="<div class='input-group'><span class='input-group-addon'><i class='icon icon-eye-open'></i></span><input type='text'name='admin'id='admin'value=''class='form-control'placeholder='管理密码'><span class='input-group-addon'>管理密码</span></div><BR/><div class='input-group'><span class='input-group-addon'><i class='icon icon-user'></i></span><input type='text'name='u'id='u'value=''class='form-control'placeholder='会员帐号'><span class='input-group-addon'>会员帐号</span></div><BR/><button onclick='admin_c();'class='btn btn-block btn-warning'type='button'>确定删除</button><br/><button onclick='fh()'class='btn btn-block btn-primary'type='button'>返回主页</button>";
	  
	  }	   
	  
	  
	  
	  
	 	  function d(){
	  
	  document.getElementById("x").innerHTML="<div class='input-group'><span class='input-group-addon'><i class='icon icon-eye-open'></i></span><input type='text'name='admin'id='admin'value=''class='form-control'placeholder='旧管理密码'><span class='input-group-addon'>旧管理密码</span></div><BR/><div class='input-group'><span class='input-group-addon'><i class='icon icon-user'></i></span><input type='text'name='u'id='u'value=''class='form-control'placeholder='新管理密码'><span class='input-group-addon'>新管理密码</span></div><BR/><button onclick='admin_d();'class='btn btn-block btn-warning'type='button'>确定修改</button><br/><button onclick='fh()'class='btn btn-block btn-primary'type='button'>返回主页</button>";
	  
	  }	 
	  
	  
		 	  function f(){
	  
	  document.getElementById("x").innerHTML="<div class='input-group'><span class='input-group-addon'><i class='icon icon-user'></i></span><input type='text'name='admin'id='admin'value=''class='form-control'placeholder='管理密码'><span class='input-group-addon'>管理密码</span></div><BR/><div class='input-group'><span class='input-group-addon'><i class='icon icon-eye-open'></i></span><input type='text'name='p'id='p'value=''class='form-control'placeholder='生成数据量'><span class='input-group-addon'>帐号数量</span></div><br/><div id='ok'></div><br/><button onclick='admin_f()'class='btn btn-block btn-info'type='button'>立即生成</button><br/><button onclick='fh()'class='btn btn-block btn-primary'type='button'>返回主页</button>";
	  
	  }	   
	  
	  
	  
	  
	  function g(){
	  
	  document.getElementById("x").innerHTML="<div class='input-group'><span class='input-group-addon'><i class='icon icon-user'></i></span><input type='text'name='admin'id='admin'value=''class='form-control'placeholder='管理密码'><span class='input-group-addon'>管理密码</span></div><BR/><div class='input-group'><span class='input-group-addon'><i class='icon icon-eye-open'></i></span><input type='text'name='p'id='p'value=''class='form-control'placeholder='会员帐号'><span class='input-group-addon'>会员帐号</span></div><br/><div id='ok'></div><br/><button onclick='admin_g()'class='btn btn-block btn-info'type='button'>立即找回</button><br/><button onclick='fh()'class='btn btn-block btn-primary'type='button'>返回主页</button>";
	  
	  }	  
	  
	  
	  
	  
	  
	  
	   function fh(){
	  
	  document.getElementById("x").innerHTML="<button onclick='a()'class='btn btn-block btn-primary'type='button'>增加流量</button><br/><button onclick='b()'class='btn btn-block btn-info'type='button'>停用帐号</button><br/><button onclick='c();'class='btn  btn-block btn-success'type='button'>删除帐号</button><br/><button onclick='d();'class='btn btn-block btn-warning'type='button'>修改密码</button><br/><button onclick='e();'class='btn btn-block btn-danger'type='button'>会员列表</button><br/><button onclick='f()'class='btn btn-block btn-primary'type='button'>生成帐号</button><br/><button onclick='g()'class='btn btn-block btn-info'type='button'>找回密码</button>";
	  
	  } 
	  
	  
	  
 
  
 function admin_a(){
	 
	 
	var admin=document.getElementById("admin").value;
var u=document.getElementById("u").value;
var l=document.getElementById("l").value;

if(admin==""){
	
	alert("请输入管理密码");
	exit();
	
	}if(u==""){
	
	alert("请输入会员帐号");
	exit();
	
	}if(l==""){
	
	alert("请输入流量数/M");
	exit();
	
	}
	
	
	xmlhttp.open("POST","../php/k.php?c=ok",false);
xmlhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
xmlhttp.send("admin="+admin+"&u="+u+"&l="+l);
var fh=xmlhttp.responseText; 

 if(fh=="1"){
	
	alert("帐号不存在");
	exit();
	
	} if(fh=="2"){
	
	alert("增加失败");
	exit();
	
	}if(fh=="3"){
	
	alert("增加成功");
	exit();
	
	}if(fh=="4"){
	
	alert("管理密码错误");
	exit();
	
	}
	 
	 
	 } 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
 function admin_b(){
	 
	 
	var admin=document.getElementById("admin").value;
var u=document.getElementById("u").value;
var objSel = document.getElementById("t");
var t=objSel.value;

if(admin==""){
	
	alert("请输入管理密码");
	exit();
	
	}if(u==""){
	
	alert("请输入会员帐号");
	exit();
	
	}if(t==""){
	
	alert("请选择状态");
	exit();
	
	}
	
	
	xmlhttp.open("POST","../php/k.php?d=ok",false);
xmlhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
xmlhttp.send("admin="+admin+"&u="+u+"&t="+t);
var fh=xmlhttp.responseText; 

 if(fh=="1"){
	
	alert("修改失败");
	exit();
	
	} if(fh=="4"){
	
	alert("帐号不存在");
	exit();
	
	}if(fh=="3"){
	
	alert("修改成功");
	exit();
	
	}if(fh=="5"){
	
	alert("管理密码错误");
	exit();
	
	}
	 
	 
	 } 	 
	 
	 






















function admin_c(){
	 
	 
	var admin=document.getElementById("admin").value;
var u=document.getElementById("u").value;


if(admin==""){
	
	alert("请输入管理密码");
	exit();
	
	}if(u==""){
	
	alert("请输入会员帐号");
	exit();
	
	}
	
	
	xmlhttp.open("POST","../php/k.php?e=ok",false);
xmlhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
xmlhttp.send("admin="+admin+"&u="+u);
var fh=xmlhttp.responseText; 

 if(fh=="1"){
	
	alert("修改失败");
	exit();
	
	} if(fh=="4"){
	
	alert("帐号不存在");
	exit();
	
	}if(fh=="3"){
	
	alert("删除成功");
	exit();
	
	}if(fh=="5"){
	
	alert("管理密码错误");
	exit();
	
	}
	 
	 
	 } 	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
function admin_d(){
	 
	 
var admin=document.getElementById("admin").value;
var u=document.getElementById("u").value;


if(admin==""){
	
	alert("请输入旧管理密码");
	exit();
	
	}if(u==""){
	
	alert("请输入新管理密码");
	exit();
	
	}
	
	
	xmlhttp.open("POST","../php/k.php?f=ok",false);
xmlhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
xmlhttp.send("admin="+admin+"&u="+u);
var fh=xmlhttp.responseText; 

 if(fh=="1"){
	
	alert("管理密码错误");
	exit();
	
	} if(fh=="2"){
	
	alert("修改失败");
	exit();
	
	}if(fh=="3"){
	
	alert("修改成功");
	exit();
	
	}
	 
	 
	 } 
	 
	 
	 
 function e(){
	 
	 
xmlhttp.open("GET","../php/hy.php",false);
xmlhttp.send();
var fh=xmlhttp.responseText; 	 
 document.getElementById("x").innerHTML=fh+"<br/><button onclick='fh()'class='btn btn-block btn-primary'type='button'>返回主页</button>";	 
	 }	 
	 
	 
 function e_a(id){
	 
	 
xmlhttp.open("GET","../php/hy.php?page="+id,false);
xmlhttp.send();
var fh=xmlhttp.responseText; 	 
 document.getElementById("x").innerHTML=fh+"<br/><button onclick='fh()'class='btn btn-block btn-primary'type='button'>返回主页</button>";	 
	 }	 
	 
	 
	 
function admin_f(){
	 
var admin=document.getElementById("admin").value;
var u=document.getElementById("p").value;


if(admin==""){
	
	alert("请输入管理密码");
	exit();
	
	}if(u==""){
	
	alert("请输入需要生成的数量");
	exit();
	
	}
	
	
	xmlhttp.open("POST","../php/k.php?g=ok",false);
xmlhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
xmlhttp.send("admin="+admin+"&u="+u);
var fh=xmlhttp.responseText; 

 if(fh=="1"){
	
	alert("管理密码错误");
	exit();
	
	} if(fh=="2"){
	
	alert("生成失败");
	exit();
	
	}if(fh.indexOf("帐号")>0){
	 document.getElementById("ok").innerHTML=fh;	 
	alert("生成成功");
	exit();
	
	}
	 
	 
	 } 
 	 
	 
	 
	 
	 
	 
	 
	 
function admin_g(){
	 
var admin=document.getElementById("admin").value;
var u=document.getElementById("p").value;


if(admin==""){
	
	alert("请输入管理密码");
	exit();
	
	}if(u==""){
	
	alert("请输入会员帐号");
	exit();
	
	}
	
	
	xmlhttp.open("POST","../php/k.php?k=ok",false);
xmlhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
xmlhttp.send("admin="+admin+"&u="+u);
var fh=xmlhttp.responseText; 

 if(fh=="1"){
	
	alert("管理密码错误");
	exit();
	
	} if(fh=="2"){
	
	alert("帐号不存在");
	exit();
	
	}if(fh.indexOf("|")>0){
	 document.getElementById("ok").innerHTML=fh;	 
	alert("找回成功");
	exit();
	
	}
	 
	 
	 } 
 	 	 