-- phpMyAdmin SQL Dump
-- version phpStudy 2014
-- http://www.phpmyadmin.net
--
-- 主机: localhost
-- 生成日期: 2016 年 05 月 28 日 12:24
-- 服务器版本: 5.1.73
-- PHP 版本: 5.3.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- 数据库: `ov`
--

-- --------------------------------------------------------

--
-- 表的结构 `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `id` int(1) NOT NULL AUTO_INCREMENT,
  `p` varchar(99) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `a` varchar(99) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- 转存表中的数据 `admin`
--

INSERT INTO `admin` (`id`, `p`, `a`) VALUES
(1, 'admiu', 'admiu');

-- --------------------------------------------------------

--
-- 表的结构 `openvpn`
--

CREATE TABLE IF NOT EXISTS `openvpn` (
  `id` int(99) NOT NULL AUTO_INCREMENT,
  `iuser` varchar(999) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL COMMENT '帐号',
  `isent` varchar(999) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL COMMENT '上传流量',
  `irecv` varchar(999) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL COMMENT '下载流量',
  `maxll` varchar(999) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL COMMENT '总流量',
  `pass` varchar(999) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL COMMENT '密码',
  `i` varchar(999) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL COMMENT '状态',
  `starttime` varchar(999) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL COMMENT '注册日期',
  `rq` varchar(999) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL COMMENT '到期日期',
  `YX` varchar(999) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `a` varchar(999) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=231 ;

--
-- 转存表中的数据 `openvpn`
--

INSERT INTO `openvpn` (`id`, `iuser`, `isent`, `irecv`, `maxll`, `pass`, `i`, `starttime`, `rq`, `YX`, `a`) VALUES
(230, '1', '0', '0', '0', '1', '1', '2016-05-28', '2016-06-27', '1', '');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
