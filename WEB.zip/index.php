﻿<?PHP include("php/V1.php");  ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>吾爱免流云流量平台</title>
<link href="css/zui.css" rel="stylesheet" type="text/css" />
<link href="css/zui.lite.css" rel="stylesheet" type="text/css" />
<link href="css/zui.lite.min.css" rel="stylesheet" type="text/css" />
<link href="css/zui.min.css" rel="stylesheet" type="text/css" />
<link href="css/zui-theme.css" rel="stylesheet" type="text/css" />
<link href="css/zui-theme.min.css" rel="stylesheet" type="text/css" />
<link href="css/css.css" rel="stylesheet" type="text/css" />
<link rel="icon" type="image/x-icon" href="img/favicon.ico">
<script src="js/zui.min.js"></script>
<script src="js/doc.min.js"></script>
<script src="js/jquery.js"></script>
<script src="js/a.js"></script>
<style type="text/css">
<!--
.STYLE1 {color: #000;font-family: "Microsoft YaHei","微软雅黑","Trebuchet MS",Arial,Verdana,Tahoma,sans-serif;}
.STYLE2 {color: #FFF}
-->
</style>
</head>

<body>

 <div class="bg-image-pattern"></div>
<div align="center">  
<img class="bg-image" src="/img/bj.jpg"> 
 
 <div class="wrapper">
 <a href="./openvpn.tar.gz"><img src='/img/wifi.png'width='28%'/></a>
 <h1 class="STYLE1"> 吾爱免流云流量平台</h1>
<br/>	

<iframe frameborder="no" border="0" marginwidth="0" marginheight="0" width=330 height=86 src="http://music.163.com/outchain/player?type=2&id=35847559&auto=1&height=66"></iframe>


<div id="x">


            <div class="input-group">
              <span class="input-group-addon"><i class="icon icon-user"></i></span>
              <input type="text" name="u" id="u" value="" class="form-control" placeholder="帐号">
              <span class="input-group-addon">会员帐号</span>
            </div>
			<BR/>
			
			<div class="input-group">
              <span class="input-group-addon"><i class="icon icon-eye-open"></i></span>
              <input type="text" name="p" id="p" value="" class="form-control" placeholder="密码">
              <span class="input-group-addon">会员密码</span>
            </div>
         
		 <br/>
		 
		 <button onclick="bba()" class="btn btn-success" type="button">立即登录</button>
		 <button onclick="zc_a()" class="btn btn-primary" type="button">注册会员</button>
		 <button onclick="alert('找回密码请咨询客服');" class="btn btn-primary" type="button">忘记密码</button>

</div>

 </div>
</div align="center">




 <div>
 
   <div align="center" class="STYLE2">官方QQ群：<a href="http://shang.qq.com/wpa/qunwpa?idkey=9c5042ab2554a88dd18e4a0c74dceefb2a6cedc4fdc9d0eb0a08722931db5f01" title="339323137" target="_blank">339323137</a> <br/>
   Copyright © 2015 - 2016. All Rights Reserved <br/> 
   <a href="http://www.52ml.org" title="吾爱免流" target="_blank">吾爱免流</a> 版权所有 </div>
 </div>

</body>
</html>






 


